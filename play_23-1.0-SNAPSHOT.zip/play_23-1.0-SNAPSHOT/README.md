Play-slick template
=================================

This is a simple slick template using play 2.3.7 with slick 0.8.1
